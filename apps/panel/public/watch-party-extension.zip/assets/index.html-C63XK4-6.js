import"./modulepreload-polyfill-B5Qt9EMX.js";const s=document.getElementById("root");s.innerHTML=`
  <h1>Watch Party Kick</h1>
  <label for="code">Codigo da sala</label>
  <input id="code" maxlength="8" placeholder="ABC123" autocomplete="off" />
  <button id="join">Entrar na sala</button>
  <button id="leave" class="ghost">Sair da watch party</button>
  <div id="status" class="status"></div>
`;const a=document.getElementById("code"),n=document.getElementById("join"),d=document.getElementById("leave"),t=document.getElementById("status");chrome.runtime.sendMessage({kind:"get-last-room"},e=>{e!=null&&e.ok&&typeof e.data=="string"&&(a.value=e.data)});a.addEventListener("input",()=>{a.value=a.value.toUpperCase().replace(/[^A-Z0-9]/g,"")});n.addEventListener("click",()=>{const e=a.value.trim();if(e.length<4){t.className="status error",t.textContent="codigo muito curto";return}n.disabled=!0,t.className="status",t.textContent="conectando...",chrome.runtime.sendMessage({kind:"join-room",code:e},o=>{n.disabled=!1,o!=null&&o.ok?(t.className="status ok",t.textContent="✓ conectado",setTimeout(()=>window.close(),500)):(t.className="status error",t.textContent=(o==null?void 0:o.error)??"falhou")})});d.addEventListener("click",()=>{chrome.runtime.sendMessage({kind:"leave-room"},()=>{t.className="status ok",t.textContent="saiu da watch party"})});
