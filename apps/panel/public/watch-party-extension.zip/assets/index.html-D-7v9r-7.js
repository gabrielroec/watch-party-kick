import"./modulepreload-polyfill-B5Qt9EMX.js";const s=document.getElementById("root");s.innerHTML=`
  <h1>Watch Party Kick</h1>
  <label for="code">Codigo da sala</label>
  <input id="code" maxlength="8" placeholder="ABC123" autocomplete="off" />
  <button id="join">Entrar na sala</button>
  <button id="leave" class="ghost">Sair da watch party</button>
  <div id="status" class="status"></div>
`;const o=document.getElementById("code"),n=document.getElementById("join"),d=document.getElementById("leave"),t=document.getElementById("status");chrome.runtime.sendMessage({kind:"get-last-room"},e=>{e!=null&&e.ok&&typeof e.data=="string"&&(o.value=e.data)});o.addEventListener("input",()=>{o.value=o.value.toUpperCase().replace(/[^A-Z0-9]/g,"")});n.addEventListener("click",()=>{const e=o.value.trim();if(e.length<4){t.className="status error",t.textContent="codigo muito curto";return}n.disabled=!0,t.className="status",t.textContent="conectando...",chrome.runtime.sendMessage({kind:"join-room",code:e},a=>{n.disabled=!1,a!=null&&a.ok?(t.className="status ok",t.textContent="conectado! Abra a aba onde quer assistir.",setTimeout(()=>window.close(),700)):(t.className="status error",t.textContent=(a==null?void 0:a.error)??"falhou")})});d.addEventListener("click",()=>{chrome.runtime.sendMessage({kind:"leave-room"},()=>{t.className="status ok",t.textContent="saiu da watch party"})});
