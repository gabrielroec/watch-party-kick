const s="https://watchpartykick.duckdns.org",a="wpk:lastRoom",o="wpk:session",t="mandiocaa";export{s as B,t as K,o as S,a};
