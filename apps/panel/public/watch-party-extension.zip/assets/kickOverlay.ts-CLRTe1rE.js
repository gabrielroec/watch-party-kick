import{R as z,a as v,T as S}from"./livekit-client.esm-C9ypCYpa.js";import{S as x}from"./config-BT6ggglQ.js";const O="wpk-overlay-root";let h=null,c=null,i=null,l=null,m=null,p=null;function d(t){return c==null?void 0:c.querySelector(t)}function y(){return document.querySelector("#channel-chatroom")}function f(){if(!c)return;const t=c.querySelector(".wpk-stage");if(!t)return;const e=y();if(e&&e.offsetWidth>0){const o=e.getBoundingClientRect(),n=Math.max(0,window.innerWidth-o.left);t.style.setProperty("--chat-w",`${n}px`),t.classList.add("wpk-has-chat")}else t.style.setProperty("--chat-w","0px"),t.classList.remove("wpk-has-chat")}function F(){const t=document.createElement("div");t.id=O,t.style.cssText="all: initial !important; position: static !important;";const e=t.attachShadow({mode:"open"});return e.innerHTML=`
    <style>
      :host { all: initial; }
      * { box-sizing: border-box; }
      .wpk-stage {
        position: fixed;
        top: 0;
        left: 0;
        bottom: 0;
        right: var(--chat-w, 0px);
        z-index: 2147483647;
        background: #0a0a0d;
        display: flex;
        flex-direction: column;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        color: #fff;
        overflow: hidden;
      }
      video {
        width: 100%;
        height: 100%;
        object-fit: contain;
        background: #000;
        display: block;
        flex: 1;
        min-height: 0;
      }
      audio { display: none; }
      .hud {
        position: absolute;
        top: 12px; left: 12px; right: 12px;
        display: flex; gap: 10px; align-items: center;
        padding: 8px 14px;
        background: linear-gradient(180deg, rgba(0,0,0,0.75), rgba(0,0,0,0));
        border-radius: 999px;
        font-size: 12px;
        pointer-events: none;
        z-index: 2;
      }
      .dot { width: 8px; height: 8px; border-radius: 50%; background: #2dd879; box-shadow: 0 0 8px #2dd879; }
      .spacer { flex: 1; }
      .stats { display: flex; gap: 10px; font-family: ui-monospace, monospace; font-size: 11px; }
      .stats .fps { color: #2dd879; }
      .controls {
        position: absolute;
        bottom: 16px; left: 16px;
        display: flex; gap: 8px;
        z-index: 2;
      }
      .btn {
        padding: 8px 14px;
        background: rgba(0,0,0,0.7);
        color: #fff;
        border: 0;
        border-radius: 8px;
        cursor: pointer;
        font-size: 13px;
        font-family: inherit;
        backdrop-filter: blur(4px);
      }
      .btn:hover { background: rgba(0,0,0,0.9); }
      .close {
        position: absolute;
        top: 14px; right: 14px;
        width: 32px; height: 32px;
        padding: 0;
        border-radius: 50%;
        font-size: 14px;
        font-weight: 700;
        z-index: 2;
      }
    </style>
    <div class="wpk-stage">
      <video id="video" autoplay muted playsinline></video>
      <audio id="audio" autoplay></audio>
      <div class="hud">
        <span class="dot"></span>
        <span id="status">conectando...</span>
        <span class="spacer"></span>
        <span class="stats"><span class="fps" id="fps">-- FPS</span></span>
      </div>
      <div class="controls">
        <button id="mute" class="btn">🔇 Som: OFF</button>
      </div>
      <button id="close" class="btn close" title="Fechar overlay">✕</button>
    </div>
  `,document.body.appendChild(t),h=t,e}async function L(t){if(!c)return;const e=d("#status"),o=d("#fps"),n=d("#video"),s=d("#audio");if(e.textContent=`${t.roomCode} · conectando`,i)try{await i.disconnect()}catch{}i=new z({adaptiveStream:!0}),i.on(v.TrackSubscribed,a=>{a.kind===S.Kind.Video?(a.attach(n),n.play().catch(()=>{})):a.kind===S.Kind.Audio&&(a.attach(s),s.play().catch(()=>{}))}),i.on(v.TrackUnsubscribed,a=>a.detach()),i.on(v.Disconnected,()=>{e.textContent=`${t.roomCode} · desconectado`});try{await i.connect(t.livekitUrl,t.livekitToken),e.textContent=`${t.roomCode} · ao vivo`}catch(a){e.textContent="erro de conexão",console.error("[wpk-overlay] connect failed",a);return}let r=0,u=performance.now();p!=null&&clearInterval(p),p=window.setInterval(()=>{var k;const a=(k=n.getVideoPlaybackQuality)==null?void 0:k.call(n),w=performance.now(),g=(w-u)/1e3;if(a&&g>0){const b=Math.round((a.totalVideoFrames-r)/g);r=a.totalVideoFrames,u=w,o.textContent=`${b} FPS`,o.style.color=b>=50?"#2dd879":b>=30?"#f0c040":"#ff5555"}},1e3)}function E(t){if(h)return;c=F(),f(),window.addEventListener("resize",f);const e=y();e&&"ResizeObserver"in window&&(l=new ResizeObserver(f),l.observe(e)),m=new MutationObserver(()=>{f();const u=y();if(u&&l)try{l.observe(u)}catch{}}),m.observe(document.body,{childList:!0,subtree:!0});const o=d("#mute"),n=d("#audio"),s=d("#close");let r=!0;n.muted=r,o.addEventListener("click",()=>{r=!r,n.muted=r,o.textContent=r?"🔇 Som: OFF":"🔊 Som: ON"}),s.addEventListener("click",()=>{C()}),L(t)}function C(){if(p!=null&&(clearInterval(p),p=null),i){try{i.disconnect()}catch{}i=null}if(l){try{l.disconnect()}catch{}l=null}if(m){try{m.disconnect()}catch{}m=null}if(window.removeEventListener("resize",f),h){try{h.remove()}catch{}h=null,c=null}}async function R(){chrome.runtime.onMessage.addListener((o,n,s)=>((o==null?void 0:o.kind)==="wpk-overlay-ping"&&s({alive:!0}),!1));const e=(await chrome.storage.local.get(x))[x];e&&E(e),chrome.storage.onChanged.addListener((o,n)=>{if(n!=="local"||!o[x])return;const s=o[x].newValue;s?E(s):C()})}R();
