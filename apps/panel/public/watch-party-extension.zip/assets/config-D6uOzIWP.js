const s="https://watchpartykick.duckdns.org",t="wpk:lastRoom",o="wpk:session";export{s as B,o as S,t as a};
