(function(){window.addEventListener("message",n=>{if(n.source!==window)return;const e=n.data;!e||e.__wpk!=="kick-bearer"||typeof e.token!="string"||chrome.runtime.sendMessage({kind:"kick-bearer",token:e.token}).catch(()=>{})});
})()
